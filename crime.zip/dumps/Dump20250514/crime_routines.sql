-- MySQL dump 10.13  Distrib 8.0.41, for Win64 (x86_64)
--
-- Host: localhost    Database: crime
-- ------------------------------------------------------
-- Server version	8.0.41

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Temporary view structure for view `view_pendingcases`
--

DROP TABLE IF EXISTS `view_pendingcases`;
/*!50001 DROP VIEW IF EXISTS `view_pendingcases`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_pendingcases` AS SELECT 
 1 AS `fileNumber`,
 1 AS `trailType`,
 1 AS `adjudicationStatus`,
 1 AS `codes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_robberies`
--

DROP TABLE IF EXISTS `view_robberies`;
/*!50001 DROP VIEW IF EXISTS `view_robberies`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_robberies` AS SELECT 
 1 AS `fileNumber`,
 1 AS `trailType`,
 1 AS `adjudicationStatus`,
 1 AS `codes`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_misdemeanors`
--

DROP TABLE IF EXISTS `view_misdemeanors`;
/*!50001 DROP VIEW IF EXISTS `view_misdemeanors`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_misdemeanors` AS SELECT 
 1 AS `codes`,
 1 AS `Offense`,
 1 AS `SentenceRange`*/;
SET character_set_client = @saved_cs_client;

--
-- Temporary view structure for view `view_caseoffenses`
--

DROP TABLE IF EXISTS `view_caseoffenses`;
/*!50001 DROP VIEW IF EXISTS `view_caseoffenses`*/;
SET @saved_cs_client     = @@character_set_client;
/*!50503 SET character_set_client = utf8mb4 */;
/*!50001 CREATE VIEW `view_caseoffenses` AS SELECT 
 1 AS `FileNumber`,
 1 AS `trailType`,
 1 AS `Offense`,
 1 AS `OffenseType`*/;
SET character_set_client = @saved_cs_client;

--
-- Final view structure for view `view_pendingcases`
--

/*!50001 DROP VIEW IF EXISTS `view_pendingcases`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_pendingcases` AS select `casefiles`.`fileNumber` AS `fileNumber`,`casefiles`.`trailType` AS `trailType`,`casefiles`.`adjudicationStatus` AS `adjudicationStatus`,`casefiles`.`codes` AS `codes` from `casefiles` where (`casefiles`.`adjudicationStatus` = false) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_robberies`
--

/*!50001 DROP VIEW IF EXISTS `view_robberies`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_robberies` AS select `casefiles`.`fileNumber` AS `fileNumber`,`casefiles`.`trailType` AS `trailType`,`casefiles`.`adjudicationStatus` AS `adjudicationStatus`,`casefiles`.`codes` AS `codes` from `casefiles` where (`casefiles`.`codes` in (1.0,1.1,1.2,1.3)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_misdemeanors`
--

/*!50001 DROP VIEW IF EXISTS `view_misdemeanors`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_misdemeanors` AS select `crimecodes`.`codes` AS `codes`,`crimecodes`.`offense` AS `Offense`,`crimecodes`.`sentenceRange` AS `SentenceRange` from `crimecodes` */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `view_caseoffenses`
--

/*!50001 DROP VIEW IF EXISTS `view_caseoffenses`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_0900_ai_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `view_caseoffenses` AS select `casefiles`.`fileNumber` AS `FileNumber`,`casefiles`.`trailType` AS `trailType`,`crimecodes`.`offense` AS `Offense`,`crimecodes`.`offenseType` AS `OffenseType` from (`casefiles` join `crimecodes` on((`casefiles`.`codes` = `crimecodes`.`codes`))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-14 18:04:53
